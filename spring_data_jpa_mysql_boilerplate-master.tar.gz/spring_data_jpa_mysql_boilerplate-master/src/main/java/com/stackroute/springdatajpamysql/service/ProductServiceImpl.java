package com.stackroute.springdatajpamysql.service;


import com.stackroute.springdatajpamysql.entity.Product;
import com.stackroute.springdatajpamysql.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

//Implement ProductService here
@Service
public class ProductServiceImpl  implements ProductService{

    private final ProductRepo productRepo;

    @Autowired
    public ProductServiceImpl(ProductRepo productRepo) {
        this.productRepo = productRepo;
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepo.findAll();
    }

    @Override
    public Product getProductById(long id) {
//
//        if (productRepo.findById(id).isEmpty()){
//            return null;
//        }

        return productRepo.findById(id).get();
    }

    @Override
    public Product saveProduct(Product product) {
        return productRepo.save(product);
    }

    @Override
    public Product updateProduct(Product product, long id) {
        Optional<Product> optionalProduct = productRepo.findById(id);
//        if (optionalProduct.isEmpty()){
//            return null;
//        }

        optionalProduct.get().setName(product.getName());
        optionalProduct.get().setPrice(product.getPrice());
        productRepo.save(optionalProduct.get());
        return product;
    }

    @Override
    public String deleteProduct(long id) {
//        if (productRepo.findById(id).isEmpty()){
//            return null;
//        }
        productRepo.deleteById(id);
        return "Product Deleted";
    }
    //Override all the methods here
}
